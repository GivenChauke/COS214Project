#ifndef BEEFBURGER_H
#define BEEFBURGER_H
#include "BurgerBase.h"

	class BeefBurger : public BurgerBase {
	public:
		BeefBurger();
		// ~BeefBuger();
	};

#endif
