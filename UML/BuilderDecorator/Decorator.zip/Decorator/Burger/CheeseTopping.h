#ifndef CHEESETOPPING_H
#define CHEESETOPPING_H
#include "BurgerTopping.h"

	class CheeseTopping : public BurgerTopping {
	public:
		CheeseTopping();
		~CheeseTopping();
	};

#endif
