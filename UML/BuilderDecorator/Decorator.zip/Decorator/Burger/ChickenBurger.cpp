#include "ChickenBurger.h"

ChickenBurger::ChickenBurger() {
	setName("Chicken Burger");
	cout << "Creating a Chicken Burger" << endl;
    setCost(5.0);
}

