#ifndef CHICKENBURGER_H
#define CHICKENBURGER_H
#include "BurgerBase.h"

	class ChickenBurger : public BurgerBase {
	public:
		ChickenBurger();
		// ~ChickenBurger();
	};

#endif
