#ifndef CHILLITOPPING_H
#define CHILLITOPPING_H
#include "BurgerTopping.h"

	class ChilliTopping : public BurgerTopping {
	public:
		ChilliTopping();
		~ChilliTopping();
	};

#endif
