#ifndef ONIONTOPPING_H
#define ONIONTOPPING_H
#include "BurgerTopping.h"

	class OnionTopping : public BurgerTopping {
	public:
		OnionTopping();
		~OnionTopping();
	};

#endif
