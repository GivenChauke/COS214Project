#include "VegetarianBurger.h"

VegetarianBurger::VegetarianBurger() {
	setName("Vegetarian Burger");
	cout << "Creating a Vegetarian Burger" << endl;
    setCost(4.0);
}

