#ifndef VEGETARIANBURGER_H
#define VEGETARIANBURGER_H
#include "BurgerBase.h"

using namespace std;

	class VegetarianBurger : public BurgerBase {
	public:
		VegetarianBurger();
		// ~VegetarianBurger();
	};

#endif
