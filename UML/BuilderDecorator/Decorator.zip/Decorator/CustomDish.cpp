// #include "CustomDish.h"

// string CustomDish::getName() {
// 	return this->name;
// }

// void CustomDish::setName(string name) {
// 	this->name = name;
// }
