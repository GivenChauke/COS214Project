#include "Alfredo.h"

Alfredo::Alfredo() : PastaType () {
	setName("Alfredo");
	cout << "Creating Alfredo" << endl;
    setCost(15.0);
}

Alfredo::~Alfredo() {
	// // TODO - implement Alfredo::~Alfredo
	// throw "Not yet implemented";
}
