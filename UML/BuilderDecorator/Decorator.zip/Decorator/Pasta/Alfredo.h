#ifndef ALFREDO_H
#define ALFREDO_H
#include "PastaType.h"

	class Alfredo : public PastaType {
	public:
		Alfredo();
		~Alfredo();
	};

#endif
