#ifndef BOLOGNAISE_H
#define BOLOGNAISE_H
#include "PastaType.h"

	class Bolognaise : public PastaType {
	public:
		Bolognaise();
		~Bolognaise();
	};

#endif
