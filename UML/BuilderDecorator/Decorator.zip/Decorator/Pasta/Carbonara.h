#ifndef CARBONARA_H
#define CARBONARA_H
#include "PastaType.h"

	class Carbonara : public PastaType {
	public:
		Carbonara();
		~Carbonara();
	};

#endif
