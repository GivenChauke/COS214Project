#ifndef MACARONI_H
#define MACARONI_H
#include "pastaBase.h"

	class Macaroni : public pastaBase {
	public:
		Macaroni();
		// ~Macaroni();
	};

#endif
