#include "Spaghetti.h"

Spaghetti::Spaghetti() {
	setName("Spaghetti");
	cout << "Creating Spaghetti" << endl;
    setCost(7.0);
}

