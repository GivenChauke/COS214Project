#ifndef SPAGHETTI_H
#define SPAGHETTI_H
#include "pastaBase.h"

	class Spaghetti : public pastaBase {
	public:
		Spaghetti();
		// ~Spaghetti();
	};

#endif
