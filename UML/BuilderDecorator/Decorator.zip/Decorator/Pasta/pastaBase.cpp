#include "pastaBase.h"

pastaBase::pastaBase() {
	// setName("Pasta Base");
}

double pastaBase::total() {
	return getCost();
}

void pastaBase::decorate(Pasta* p) {
	// // TODO - implement pastaBase::decorate
	// throw "Not yet implemented";
}

pastaBase::~pastaBase() {
	// // TODO - implement pastaBase::~pastaBase
	// throw "Not yet implemented";
}
