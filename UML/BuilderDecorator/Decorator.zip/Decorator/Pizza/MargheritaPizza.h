#ifndef MARGHERITAPIZZA_H
#define MARGHERITAPIZZA_H
#include "PizzaType.h"

	class MargheritaPizza : public PizzaType {
	public:
		MargheritaPizza();
		~MargheritaPizza();
	};

#endif
