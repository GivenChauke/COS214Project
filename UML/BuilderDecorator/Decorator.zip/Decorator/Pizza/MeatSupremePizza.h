#ifndef MEATSUPREMEPIZZA_H
#define MEATSUPREMEPIZZA_H
#include "PizzaType.h"

	class MeatSupremePizza : public PizzaType {
	public:
		MeatSupremePizza();
		~MeatSupremePizza();
	};

#endif
