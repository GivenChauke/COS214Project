#ifndef PEPPERONIPIZZA_H
#define PEPPERONIPIZZA_H
#include "PizzaType.h"

	class PepperoniPizza : public PizzaType {
	public:
		PepperoniPizza();
		~PepperoniPizza();
	};

#endif
