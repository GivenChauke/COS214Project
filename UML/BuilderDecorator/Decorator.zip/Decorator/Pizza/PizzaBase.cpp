#include "PizzaBase.h"

PizzaBase::PizzaBase() {
	// setName("Pizza Base");
}

double PizzaBase::total() {
	return getCost(); 
}

void PizzaBase::decorate(Pizza* p) {
	// TODO - implement PizzaBase::decorate
	// throw "Not yet implemented";
}

PizzaBase::~PizzaBase() {
	// // TODO - implement PizzaBase::~PizzaBase
	// throw "Not yet implemented";
}
