#ifndef THICKBASEPIZZA_H
#define THICKBASEPIZZA_H
#include "PizzaBase.h"


	class ThickBasePizza : public PizzaBase {
	public:
		ThickBasePizza();
		// ~ThickBasePizza();
	};

#endif
