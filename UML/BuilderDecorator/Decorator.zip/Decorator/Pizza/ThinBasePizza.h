#ifndef THINBASEPIZZA_H
#define THINBASEPIZZA_H
#include "PizzaBase.h"

	class ThinBasePizza : public PizzaBase {
	public:
		ThinBasePizza();
		// ~ThinBasePizza();
	};

#endif
