#include "AbstractDishBuilder.h"

// void AbstractDishBuilder::addPizzaToppings(int string) {
// 	// TODO - implement AbstractDishBuilder::addPizzaToppings
// 	throw "Not yet implemented";
// }

// void AbstractDishBuilder::addBurgerExtras(int string) {
// 	// TODO - implement AbstractDishBuilder::addBurgerExtras
// 	throw "Not yet implemented";
// }

// void AbstractDishBuilder::addPastaExtras(int string) {

// 	//instead of this code in the  i want to call the first half here (Alfredo/Carbonara) where it will get that as input and then call the second half in DishBuilder::buildPasta() where it will have the input for the rest of the decorating (Macaroni/Spaghetti)

// 	// Pasta* myPasta;
//     // myPasta = new Alfredo();
//     // myPasta->decorate(new Spaghetti());
//     // cout << "Cost = " << myPasta->total() << endl;

//     // Pasta* myPasta;
//     // myPasta = new Carbonara();
//     // myPasta->decorate(new Macaroni());
//     // cout << "Cost = " << myPasta->total() << endl;
//     // delete myPasta;
// }

// void AbstractDishBuilder::addCustomDishExtras(int string) {
// 	// TODO - implement AbstractDishBuilder::addCustomDishExtras
// 	throw "Not yet implemented";
// }
