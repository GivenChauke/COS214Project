var searchData=
[
  ['vegetarianburger_0',['VegetarianBurger',['../class_vegetarian_burger.html#a67b0960bfa43c6075318b5f514848f77',1,'VegetarianBurger']]],
  ['visittable_1',['visitTable',['../class_abstract_table.html#ab3f22f1075ecc85769199646fc6138c1',1,'AbstractTable']]]
];
