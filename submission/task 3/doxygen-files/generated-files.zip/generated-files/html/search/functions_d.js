var searchData=
[
  ['pasta_0',['Pasta',['../class_pasta.html#ab9f564c7fb92d98a9cfdb9d58ac4cffd',1,'Pasta']]],
  ['pastabase_1',['pastaBase',['../classpasta_base.html#a3db7f8a4a9395c95801255fcc05bdf86',1,'pastaBase']]],
  ['pastatype_2',['PastaType',['../class_pasta_type.html#a4ef0b05d0e2b66ecd9b2c1284ae2b81c',1,'PastaType']]],
  ['paybill_3',['paybill',['../class_abstract_table.html#a0a7a27059a88d0bb30e46ba15451813d',1,'AbstractTable::payBill()'],['../class_customer_group.html#a0afa8f6bf21eac435e81678248574218',1,'CustomerGroup::PayBill()']]],
  ['pepperonipizza_4',['PepperoniPizza',['../class_pepperoni_pizza.html#aca9a1acd688b219d8e1c2d5b9e0f8f5b',1,'PepperoniPizza']]],
  ['pizza_5',['Pizza',['../class_pizza.html#a2d699a68b26253cae3b2d87019deb8ec',1,'Pizza']]],
  ['pizzabase_6',['PizzaBase',['../class_pizza_base.html#a23a2fe92cea8527a3c769c7883b4baf2',1,'PizzaBase']]],
  ['pizzatype_7',['PizzaType',['../class_pizza_type.html#aa41247eeea1cea3e9caf676318854617',1,'PizzaType']]],
  ['placeorder_8',['placeorder',['../class_abstract_table.html#a0280139328ce72ee5eb6290aae0f2b95',1,'AbstractTable::PlaceOrder()'],['../class_combined_table.html#ab9edd981be7a48cf067b2bac298b200c',1,'CombinedTable::PlaceOrder()'],['../class_customer.html#aa02a2407b456629e5a7666c0ec225261',1,'Customer::PlaceOrder()'],['../class_customer_group.html#aff9e62e47ec22973d2158fda5d9f7a82',1,'CustomerGroup::PlaceOrder()']]],
  ['print_9',['print',['../class_bill.html#aa67e63b7fb0b2f0b79f377c95f475d0d',1,'Bill::print()'],['../class_customer_group.html#a29d41dcaaae610d29a916fdf79143ffd',1,'CustomerGroup::print()'],['../class_order.html#adf058dc273a7638a685ad3051f10b676',1,'Order::print()']]],
  ['printmenu_10',['printMenu',['../class_menu.html#ab5221fe6ff46005a6031a8a1cd961636',1,'Menu']]],
  ['printtablesandwaiters_11',['printTablesAndWaiters',['../class_floor.html#abf84d9d6d4afaf5f3d1478a93206e315',1,'Floor']]]
];
