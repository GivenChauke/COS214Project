var searchData=
[
  ['positivecomment_0',['PositiveComment',['../class_random_string.html#ab0bf3f1886873acce0e7597f9573b6d2',1,'RandomString']]],
  ['price_1',['price',['../struct_food_item.html#a78ee2f9684e7ccbe50801459e4eef1ef',1,'FoodItem']]]
];
