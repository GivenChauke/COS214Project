#include "BeefBurger.h"

BeefBurger::BeefBurger() {
	setName("Beef Burger");
	cout << "Creating a Beef Burger" << endl;
    setCost(6.0);
}
