#include "ThickBasePizza.h"

ThickBasePizza::ThickBasePizza() {
	setName("Thick Base Pizza");
	cout << "Creating a thick base" << endl;
    setCost(2.0);
}

