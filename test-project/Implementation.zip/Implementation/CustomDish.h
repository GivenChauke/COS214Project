// #ifndef CUSTOMDISH_H
// #define CUSTOMDISH_H
// #include "Food.h"
// #include <string>
// using namespace std;

// 	class CustomDish : public Food {

// 	public:
// 		string name;
// 		string getName();
// 		void setName(string name);
// 	};

// #endif
