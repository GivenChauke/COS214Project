#include "Macaroni.h"

Macaroni::Macaroni() {
	setName("Macaroni");
	cout << "Creating Macaroni" << endl;
    setCost(6.0);
}

