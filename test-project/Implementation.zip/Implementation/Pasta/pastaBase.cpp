#include "pastaBase.h"

pastaBase::pastaBase() {
}

double pastaBase::total() {
	return getCost();
}

void pastaBase::decorate(Pasta* p) {
}

pastaBase::~pastaBase() {
}
