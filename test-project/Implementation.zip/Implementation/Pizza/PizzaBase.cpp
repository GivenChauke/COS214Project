#include "PizzaBase.h"

PizzaBase::PizzaBase() {
}

double PizzaBase::total() {
	return getCost(); 
}

void PizzaBase::decorate(Pizza* p) {
}

PizzaBase::~PizzaBase() {
}
