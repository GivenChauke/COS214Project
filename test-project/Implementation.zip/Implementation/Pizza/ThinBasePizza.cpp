#include "ThinBasePizza.h"

ThinBasePizza::ThinBasePizza() {
	setName("Thin Base Pizza");
	cout << "Creating a thin base" << endl;
    setCost(1.00);
}

