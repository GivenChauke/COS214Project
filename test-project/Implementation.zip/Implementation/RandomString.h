#ifndef RANDOM_STRING_H
#define RANDOM_STRING_H
#include <string>
using namespace std;
#include<iostream>

class RandomString
{
    public:
        static string PositiveComment[10];
        static string NegativeComment[10];
    // protected:
    //     RandomString();
};



string RandomString::PositiveComment[10]={"The food was the best ever","I enjoyed the food","dont change the receipt it works", "I wish could order more", "Best Resturant in the city", "Your food 100% amazing","Give the chefs a raise pls","I dont think i have eaten such a meal in a long time", "The meal was mouth watering", "Definetely scrambious"};
// string RandomString::PositiveComment[1]="kmnb";
// string RandomString::PositiveComment[2]="kmnb";
// string RandomString::PositiveComment[3]="kmnb";
// string RandomString::PositiveComment[4]="kmnb";
// string RandomString::PositiveComment[5]="kmnb";
// string RandomString::PositiveComment[6]="kmnb";
// string RandomString::PositiveComment[7]="kmnb";
// string RandomString::PositiveComment[8]="kmnb";
// string RandomString::PositiveComment[9]="kmnb";

string RandomString::NegativeComment[10]={"The food was undone","you guys cant cook","definetely wasted my money", "i think the best was expired", "Bad  expreince", "I am never coming here again","Lower Quality","I hate it here", "my mom can cook better than this", "WACK menu"};
// string RandomString::NegativeComment[1]="kmnb";
// string RandomString::NegativeComment[2]="kmnb";
// string RandomString::NegativeComment[3]="kmnb";
// string RandomString::NegativeComment[4]="kmnb";
// string RandomString::NegativeComment[5]="kmnb";
// string RandomString::NegativeComment[6]="kmnb";
// string RandomString::NegativeComment[7]="kmnb";
// string RandomString::NegativeComment[8]="kmnb";
// string RandomString::NegativeComment[9]="kmnb";


#endif